# <h1>JPA-con-hibernate-Alura</h1>

proyecto: <h2>hibernate y jpa</h2>

En este curso online de JPA tendremos una serie de lecciones en vídeo sobre Java Persistence API 1.0, especificación que es el resultado de años de trabajo de su creador Gavin King con este curso van a conseguir dominar el framework java más utilizado en el mercado actual, Trabajar con JPA  y obtener conexiones a bases de datos y operar con entidades

<ol>
  <li>Comprenda los problemas de JDBC y cómo JPA llegó a resolverlos</li>
  <li>Aprenda a agregar JPA en una aplicación Java con Maven</li>
  <li>Configure jpa a través del archivo de persistencia.xml</li>
  <li>Mapee entidades JPA y sus relaciones</li>
  <li>Comprenda cómo funciona el ciclo de vida de una entidad JPA</li>
  <li>Realize consultas a través de JPQL</li>
</ol>

links

1) dependencias
<a>https://mvnrepository.com/</a>

2)ide
https://www.eclipse.org/downloads/download.php?file=/oomph/epp/2022-12/R/eclipse-inst-jre-win64.exe&mirror_id=576
https://code.visualstudio.com/Download

